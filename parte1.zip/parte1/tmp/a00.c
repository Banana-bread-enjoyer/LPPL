// Ejemplo de uso de operadores aritmeticos
//-----------------------------------------
int main ()
{ int a; int b=0;

  read(a);
  a = (((a + a) * 2) / 2 ) - a ;
  print(a);
  print (a=b=7); print (a); print (b);
  
  return 0;
}
