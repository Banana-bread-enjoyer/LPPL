// Ejemplo de uso de operadores logicos y relacionales
//------------------_---------------------------------
int main ()
{ int x; int y; bool z;

  if (true){}
  else{}
  
  return 0;
} 
